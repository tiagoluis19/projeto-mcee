function A = transform_fontes (R, A)
A = A*R;
end